/* TiempoMDZ 1.12 · Avisos sobre la ruta.
   El usuario elige origen y destino (buscando un lugar, "mi ubicación" o tocando el mapa), la hora de salida
   y el tipo de vehículo. La app traza el camino, lo divide en puntos cada ~15-30 km, calcula a qué hora
   pasaría por cada uno y mira el pronóstico PARA ESA HORA (no el de ahora), el satélite en los puntos
   cercanos en el tiempo y los avisos oficiales del SMN. Es una estimación: no reemplaza informes oficiales
   ni el estado de rutas (Vialidad, Gendarmería, Contingencias). */
(function (root) {
  'use strict';
  const OSRM = 'https://router.project-osrm.org/route/v1/driving/';
  const GEO = 'https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=ar&q=';
  const VEH = { auto: 1, camion: 1.25 };
  const RANK = { hail: 3, stormStrong: 2, stormWeak: 1 };
  const LABEL = { hail: ['🧊', 'Granizo o tormenta severa'], stormStrong: ['⛈', 'Tormenta fuerte'], stormWeak: ['🌦', 'Lluvia débil'], wind: ['💨', 'Viento fuerte'], frost: ['🥶', 'Helada'], zonda: ['🌬', 'Zonda (aviso SMN)'] };
  const PRIO = ['hail', 'stormStrong', 'zonda', 'wind', 'frost', 'stormWeak'];
  const TIP = 'Considerá esperar, cambiar el horario de salida o buscar un lugar seguro antes de ese tramo.';
  // Referencias aproximadas para nombrar los tramos ("cerca de …"). No se usan para calcular nada.
  const TOWNS = [
    ['Mendoza', -32.89, -68.84], ['Luján de Cuyo', -33.04, -68.88], ['Potrerillos', -32.96, -69.2], ['Uspallata', -32.59, -69.35],
    ['Las Cuevas', -32.82, -70.05], ['Tunuyán', -33.57, -69.02], ['San Martín', -33.08, -68.47], ['Junín', -33.15, -68.49],
    ['Rivadavia', -33.19, -68.47], ['Santa Rosa', -33.25, -68.15], ['La Paz', -33.46, -67.55], ['San Rafael', -34.62, -68.33],
    ['Malargüe', -35.47, -69.58], ['San Juan', -31.54, -68.52], ['San Luis', -33.3, -66.34], ['Villa Mercedes', -33.68, -65.46],
    ['Justo Daract', -33.86, -65.18], ['Río Cuarto', -33.13, -64.35], ['Laboulaye', -34.13, -63.39], ['Rufino', -34.26, -62.71],
    ['Venado Tuerto', -33.75, -61.97], ['Junín (BA)', -34.59, -60.95], ['Pergamino', -33.89, -60.57], ['Chacabuco', -34.64, -60.47],
    ['Areco', -34.25, -59.47], ['Luján', -34.57, -59.11], ['Buenos Aires', -34.6, -58.38], ['Rosario', -32.95, -60.64], ['Córdoba', -31.42, -64.18]
  ];
  const D2R = Math.PI / 180;
  const hav = (lat1, lon1, lat2, lon2) => {
    const a = Math.sin((lat2 - lat1) * D2R / 2) ** 2 + Math.cos(lat1 * D2R) * Math.cos(lat2 * D2R) * Math.sin((lon2 - lon1) * D2R / 2) ** 2;
    return 12742 * Math.asin(Math.min(1, Math.sqrt(a)));
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hhmm = ms => new Date(ms).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
  const dayhh = ms => { const d = new Date(ms), t = new Date(); const same = d.toDateString() === t.toDateString(); return (same ? '' : d.toLocaleDateString('es-AR', { weekday: 'short' }) + ' ') + hhmm(ms); };

  // coords = [[lon,lat],...] (GeoJSON). Devuelve km acumulados por vértice.
  function cumulative(coords) {
    const cum = [0];
    for (let i = 1; i < coords.length; i++) cum.push(cum[i - 1] + hav(coords[i - 1][1], coords[i - 1][0], coords[i][1], coords[i][0]));
    return cum;
  }
  function samplePoints(coords, cum, stepKm) {
    const total = cum[cum.length - 1] || 0, out = [];
    if (!coords.length) return out;
    const at = km => {
      let i = 1; while (i < cum.length - 1 && cum[i] < km) i++;
      const a = coords[i - 1], b = coords[i] || a, seg = (cum[i] - cum[i - 1]) || 1, t = Math.max(0, Math.min(1, (km - cum[i - 1]) / seg));
      return { lat: a[1] + (b[1] - a[1]) * t, lon: a[0] + (b[0] - a[0]) * t, km, frac: total ? km / total : 0 };
    };
    for (let km = 0; km < total; km += stepKm) out.push(at(km));
    out.push(at(total));
    return out;
  }
  function sliceCoords(coords, cum, k0, k1) {
    const out = [];
    for (let i = 0; i < coords.length; i++) if (cum[i] >= k0 - 1e-6 && cum[i] <= k1 + 1e-6) out.push([coords[i][1], coords[i][0]]);
    return out.length >= 2 ? out : [];
  }
  function nearestTown(lat, lon) {
    let best = null, bd = 1e9;
    TOWNS.forEach(t => { const d = hav(lat, lon, t[1], t[2]); if (d < bd) { bd = d; best = t[0]; } });
    return bd <= 22 ? best : null;
  }
  const placeName = p => nearestTown(p.lat, p.lon) || ('km ' + Math.round(p.km));

  // h = { time[], weather_code[], precipitation[], wind_gusts_10m[], temperature_2m[], cape[], lifted_index[] } (UTC)
  // Evalúa las horas que cubren el paso por el punto (±30 min). sat = { min, cold } solo para pasos de la próxima hora.
  function evalPoint(h, etaMs, cfg, sat) {
    const out = {};
    const add = (type, level, detail) => { if (!out[type] || out[type].level < level) out[type] = { type, level, detail }; };
    const windKmh = (cfg && cfg.windKmh) || 60, frostC = (cfg && Number.isFinite(+cfg.frostC)) ? +cfg.frostC : 2;
    (h.time || []).forEach((t, i) => {
      const hs = Date.parse(t + 'Z');
      if (!(hs < etaMs + 30 * 60e3 && hs + 3600e3 > etaMs - 30 * 60e3)) return;
      const x = { cape: (h.cape || [])[i], lifted_index: (h.lifted_index || [])[i] };
      if (sat && sat.min != null) { x.ctt = sat.min; x.cold = sat.cold; }
      const k = root.stormClass ? root.stormClass((h.weather_code || [])[i], (h.precipitation || [])[i] || 0, x) : null;
      if (k) add(k, RANK[k], (k === 'hail' ? 'Posible granizo' : k === 'stormStrong' ? 'Tormenta con lluvia intensa y rayos' : 'Lluvia o tormenta débil') + (x.ctt != null && x.ctt <= -40 ? ' · el satélite ve nubes de tormenta muy altas' : ''));
      const g = (h.wind_gusts_10m || [])[i];
      if (g != null && g >= windKmh) add('wind', g >= windKmh + 40 ? 3 : g >= windKmh + 20 ? 2 : 1, 'Ráfagas de hasta ' + Math.round(g) + ' kilómetros por hora');
      const tt = (h.temperature_2m || [])[i];
      if (tt != null && tt <= frostC) add('frost', 2, (window.plain||String)('Temperatura de ' + Math.round(tt) + ' °C'));
    });
    return Object.values(out);
  }
  const topOf = evs => evs.slice().sort((a, b) => b.level - a.level || PRIO.indexOf(a.type) - PRIO.indexOf(b.type))[0] || null;

  // pts = [{km, eta, events:[{type,level,detail,official?}], level}]  → tramos consecutivos de nivel >= 2
  function buildSegments(pts) {
    const segs = []; let cur = null;
    pts.forEach((p, i) => {
      const lvl = p.level >= 2 ? p.level : 0;
      if (lvl) {
        if (!cur) { cur = { i0: i, i1: i, level: lvl, ev: {} }; segs.push(cur); }
        cur.i1 = i; cur.level = Math.max(cur.level, lvl);
        p.events.filter(e => e.level >= 2 || e.type === 'zonda').forEach(e => { if (!cur.ev[e.type] || cur.ev[e.type].level < e.level) cur.ev[e.type] = e; });
      } else cur = null;
    });
    return segs.map(s => {
      const a = pts[s.i0], b = pts[s.i1], list = Object.values(s.ev).sort((x, y) => y.level - x.level || PRIO.indexOf(x.type) - PRIO.indexOf(y.type));
      return { from: a, to: b, level: s.level, events: list, etaFrom: a.eta, etaTo: b.eta, kmFrom: a.km, kmTo: b.km };
    });
  }

  async function getJson(url, ms) {
    const c = new AbortController(), t = setTimeout(() => c.abort(), ms || 12000);
    try { const r = await fetch(url, { signal: c.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json(); }
    finally { clearTimeout(t); }
  }
  async function fetchRoute(a, b) {
    const j = await getJson(OSRM + a.lon + ',' + a.lat + ';' + b.lon + ',' + b.lat + '?overview=full&geometries=geojson&steps=false', 15000);
    const r = j && j.routes && j.routes[0];
    if (!r || !r.geometry || !r.geometry.coordinates || r.geometry.coordinates.length < 2) throw new Error('No encontré un camino entre esos dos puntos.');
    return { coords: r.geometry.coordinates, km: r.distance / 1000, sec: r.duration };
  }
  async function fetchWx(points, hours) {
    const out = [], H = 'temperature_2m,weather_code,precipitation,wind_gusts_10m,cape,lifted_index';
    for (let i = 0; i < points.length; i += 50) {
      const ch = points.slice(i, i + 50);
      const u = 'https://api.open-meteo.com/v1/forecast?latitude=' + ch.map(p => p.lat.toFixed(3)).join(',') + '&longitude=' + ch.map(p => p.lon.toFixed(3)).join(',') +
        '&hourly=' + H + '&forecast_hours=' + hours + '&timezone=UTC&wind_speed_unit=kmh';
      const j = await getJson(u, 15000);
      (Array.isArray(j) ? j : [j]).forEach(d => out.push(d.hourly));
    }
    if (out.length !== points.length || out.some(h => !h || !h.time)) throw new Error('El pronóstico de la ruta llegó incompleto.');
    return out;
  }

  // opts = { from, to, departMin, veh }
  async function analyze(opts, cfg, routeCache) {
    const key = [opts.from.lat, opts.from.lon, opts.to.lat, opts.to.lon].map(v => (+v).toFixed(4)).join(',');
    let rt = routeCache && routeCache.key === key ? routeCache.rt : null;
    if (!rt) { rt = await fetchRoute(opts.from, opts.to); rt.cum = cumulative(rt.coords); }
    const factor = VEH[opts.veh] || 1.25, totalSec = rt.sec * factor, now = Date.now(), depart = now + (opts.departMin || 0) * 60e3;
    const step = Math.max(15, Math.min(30, rt.km / 45));
    const pts = samplePoints(rt.coords, rt.cum, step).map(p => Object.assign(p, { eta: depart + p.frac * totalSec * 1000, events: [], level: 0 }));
    const lastEta = pts[pts.length - 1].eta, hours = Math.min(48, Math.max(6, Math.ceil((lastEta - now) / 3600e3) + 3));
    if ((lastEta - now) > 46 * 3600e3) throw new Error('El viaje termina más allá de lo que el pronóstico cubre (48 h). Probá con una salida más cercana.');
    const wx = await fetchWx(pts, hours);
    // satélite: solo sirve para los puntos que se cruzan en la próxima hora
    let sat = null;
    const near = pts.map((p, i) => ({ p, i })).filter(x => x.p.eta - now <= 60 * 60e3);
    if (near.length && near.length <= 40 && typeof root.fetchCloudTops === 'function') {
      try { const r = await root.fetchCloudTops(near.map(x => [x.p.lat, x.p.lon])); if (r) { sat = {}; near.forEach((x, k) => { if (r[k]) sat[x.i] = r[k]; }); } } catch (e) { sat = null; }
    }
    pts.forEach((p, i) => { p.events = evalPoint(wx[i], p.eta, cfg, sat && sat[i]); });
    // avisos oficiales vigentes del SMN que cubren cada punto
    if (typeof root.fetchOfficialAlertsForPoint === 'function') {
      let official = true;
      for (let i = 0; i < pts.length && official; i += 12) {
        try {
          const batch = await Promise.all(pts.slice(i, i + 12).map(p => root.fetchOfficialAlertsForPoint({ lat: p.lat, lon: p.lon, name: placeName(p) }).catch(() => [])));
          batch.forEach((list, k) => (list || []).forEach(e => pts[i + k].events.push({ type: e.type, level: e.level, detail: 'Aviso oficial del SMN vigente: ' + (e.title || ''), official: true })));
        } catch (e) { official = false; }
      }
    }
    pts.forEach(p => { const t = topOf(p.events); p.level = t ? t.level : 0; p.top = t; p.place = placeName(p); });
    const segs = buildSegments(pts);
    return { rt, key, pts, segs, km: rt.km, depart, arrive: lastEta, hours: totalSec / 3600, factor, weakOnly: !segs.length && pts.some(p => p.level === 1) };
  }

  const api = { hav, samplePoints, cumulative, sliceCoords, nearestTown, evalPoint, buildSegments, topOf, analyze, TOWNS, VEH };
  root.RouteWx = api;

  /* ------------------------------ interfaz ------------------------------ */
  if (typeof document === 'undefined' || !document.getElementById('map') || typeof L === 'undefined') return;
  const $ = id => document.getElementById(id);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const LSg = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const LSs = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  const buzz = () => { try { if (typeof hap === 'function') hap(); } catch (e) { } };
  const R = Object.assign({ from: null, to: null, depart: 0, veh: 'camion' }, LSg('mx_route', {}));
  const save = () => LSs('mx_route', { from: R.from, to: R.to, depart: R.depart, veh: R.veh });
  const group = L.layerGroup();
  let busy = false, last = null, cache = null, timer = 0, seenKeys = {};

  const back = el('div', 'mx-back'); document.body.appendChild(back);
  const sheet = el('div', 'mx-sheet mx-route'); sheet.id = 'mx-route'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'Avisos en tu ruta');
  sheet.innerHTML = '<div class="mx-grab"></div><h3>🛣 Avisos en tu ruta<button type="button" class="mx-x" aria-label="Cerrar">✕</button></h3><div class="mx-body"></div>';
  document.body.appendChild(sheet);
  const body = sheet.querySelector('.mx-body');
  const open = () => { sheet.classList.add('show'); back.classList.add('show'); sheet.scrollTop = 0; };
  const close = () => { sheet.classList.remove('show'); back.classList.remove('show'); };
  sheet.querySelector('.mx-x').onclick = close; back.addEventListener('click', () => { if (sheet.classList.contains('show')) close(); });

  let toastEl = null, toastT = 0;
  function toast(msg) {
    if (!toastEl) { toastEl = el('div', 'mx-rtoast'); document.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), 4200);
  }

  function placeBox(kind, title) {
    const box = el('div', 'rt-place');
    box.innerHTML = '<label>' + title + '</label><div class="rt-in"><input type="text" inputmode="search" autocomplete="off" placeholder="Ciudad, pueblo o lugar"><button type="button" class="go">Buscar</button></div>' +
      '<div class="rt-q"><button type="button" class="me">📍 Mi ubicación</button><button type="button" class="pick">🗺 Elegir en el mapa</button></div><div class="rt-res"></div>';
    const inp = box.querySelector('input'), res = box.querySelector('.rt-res');
    const set = p => { R[kind] = p; save(); inp.value = p.name; res.innerHTML = ''; };
    if (R[kind]) inp.value = R[kind].name;
    const search = async () => {
      const q = inp.value.trim(); if (q.length < 2) return;
      res.innerHTML = '<div class="rt-hint">Buscando…</div>';
      try {
        const j = await getJson(GEO + encodeURIComponent(q), 9000);
        if (!j.length) { res.innerHTML = '<div class="rt-hint">No encontré ese lugar. Probá con otro nombre o elegilo en el mapa.</div>'; return; }
        res.innerHTML = '';
        j.forEach(r => { const b = el('button', 'rt-opt', esc(r.display_name.split(',').slice(0, 3).join(','))); b.type = 'button'; b.onclick = () => set({ name: r.display_name.split(',')[0], lat: +r.lat, lon: +r.lon }); res.appendChild(b); });
      } catch (e) { res.innerHTML = '<div class="rt-hint">No pude buscar ahora (sin internet o servicio ocupado). Podés elegir el punto en el mapa.</div>'; }
    };
    box.querySelector('.go').onclick = search;
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); search(); } });
    box.querySelector('.me').onclick = () => { try { const p = cur(); if (p && p.lat != null) set({ name: p.name || 'Mi ubicación', lat: +p.lat, lon: +p.lon }); } catch (e) { toast('No pude leer tu ubicación'); } };
    box.querySelector('.pick').onclick = () => {
      close(); toast('Tocá el mapa para elegir ' + (kind === 'from' ? 'el origen' : 'el destino'));
      const cont = map.getContainer(); cont.style.cursor = 'crosshair'; root.__pickingRoute = true;
      map.once('click', e => { cont.style.cursor = ''; setTimeout(() => { root.__pickingRoute = false; }, 0); set({ name: 'Punto en el mapa', lat: e.latlng.lat, lng: e.latlng.lng, lon: e.latlng.lng }); build(); open(); });
    };
    return box;
  }

  function build() {
    body.innerHTML = '';
    body.appendChild(placeBox('from', 'Desde'));
    body.appendChild(placeBox('to', 'Hasta'));
    const opts = el('div', 'rt-opts');
    opts.innerHTML = '<div><label>Salida</label><select id="rtDep"><option value="0">Ahora</option><option value="60">En 1 hora</option><option value="120">En 2 horas</option><option value="180">En 3 horas</option><option value="360">En 6 horas</option><option value="720">En 12 horas</option></select></div>' +
      '<div><label>Vehículo</label><select id="rtVeh"><option value="camion">Camión o carga</option><option value="auto">Auto</option></select></div>';
    body.appendChild(opts);
    opts.querySelector('#rtDep').value = String(R.depart || 0); opts.querySelector('#rtVeh').value = R.veh || 'camion';
    opts.querySelector('#rtDep').onchange = e => { R.depart = +e.target.value; save(); };
    opts.querySelector('#rtVeh').onchange = e => { R.veh = e.target.value; save(); };
    const go = el('button', 'rt-go', '🔍 Revisar la ruta'); go.type = 'button'; go.onclick = () => run(true); body.appendChild(go);
    const del = el('button', 'rt-del', '🗑 Borrar ruta'); del.type = 'button'; del.onclick = () => clearRoute(true); body.appendChild(del);
    const out = el('div', 'rt-out'); out.id = 'rtOut'; body.appendChild(out);
    body.appendChild(el('p', 'rt-note', 'Es una estimación con pronóstico de modelos, satélite y avisos del SMN para la hora en que pasarías por cada tramo. No reemplaza los informes oficiales ni el estado de las rutas (Vialidad, Gendarmería, Contingencias). Ante dudas, no viajes.'));
    if (last) render(last);
  }

  function colorOf(l) { return l >= 3 ? '#ff1744' : l === 2 ? '#ff9100' : l === 1 ? '#ffd600' : '#2fbf71'; }
  function draw(res) {
    group.clearLayers(); if (!map.hasLayer(group)) group.addTo(map);
    const all = res.rt.coords.map(c => [c[1], c[0]]);
    L.polyline(all, { color: '#35b6ff', weight: 5, opacity: .85 }).addTo(group);
    res.segs.forEach(s => {
      const sl = sliceCoords(res.rt.coords, res.rt.cum, s.kmFrom - 12, s.kmTo + 12);
      if (sl.length) L.polyline(sl, { color: colorOf(s.level), weight: 8, opacity: .95 }).addTo(group);
      const mid = res.pts[Math.floor((res.pts.indexOf(s.from) + res.pts.indexOf(s.to)) / 2)];
      const t = s.events[0], lb = LABEL[t.type] || ['⚠️', 'Aviso'];
      L.marker([mid.lat, mid.lon], { icon: L.divIcon({ className: '', iconSize: [34, 34], iconAnchor: [17, 17], html: '<div class="rt-pin" style="background:' + colorOf(s.level) + '">' + lb[0] + '</div>' }) })
        .addTo(group).bindPopup('<b>' + lb[1] + '</b><br>' + esc(mid.place) + '<br>Pasarías ~' + dayhh(s.etaFrom) + (s.etaTo - s.etaFrom > 20 * 60e3 ? ' a ' + dayhh(s.etaTo) : ''));
    });
    const a = res.pts[0], b = res.pts[res.pts.length - 1];
    [[a, 'A', '#2fbf71'], [b, 'B', '#e53935']].forEach(([p, t, c]) => L.marker([p.lat, p.lon], { icon: L.divIcon({ className: '', iconSize: [28, 28], iconAnchor: [14, 14], html: '<div class="rt-pin sm" style="background:' + c + '">' + t + '</div>' }) }).addTo(group));
    try { map.fitBounds(L.latLngBounds(all), { padding: [30, 30] }); } catch (e) { }
  }

  function render(res) {
    const out = $('rtOut'); if (!out) return;
    let h = '<div class="rt-sum">' + Math.round(res.km) + ' km · ~' + (res.hours >= 1 ? Math.floor(res.hours) + ' h ' + Math.round((res.hours % 1) * 60) + ' min' : Math.round(res.hours * 60) + ' min') +
      ' · llegada estimada ' + dayhh(res.arrive) + '</div>';
    if (!res.segs.length) {
      h += '<div class="rt-ok">✅ <b>Sin avisos importantes en la ruta</b><br>' + (res.weakOnly ? 'Hay lluvia débil en algunos tramos, sin tormenta fuerte ni viento intenso previstos.' : 'No se prevén tormentas fuertes, granizo, viento fuerte ni heladas para las horas en que pasarías.') + '</div>';
    } else {
      h += '<div class="rt-warn">⚠️ <b>' + res.segs.length + (res.segs.length > 1 ? ' tramos con riesgo' : ' tramo con riesgo') + '</b></div>';
      res.segs.forEach(s => {
        const t = s.events[0], lb = LABEL[t.type] || ['⚠️', 'Aviso'], a = s.from.place, b = s.to.place;
        const unnamed = /^km /.test(a) && /^km /.test(b), where = unnamed ? 'tramo sin pueblos de referencia' : a === b ? 'cerca de ' + esc(a) : 'entre ' + esc(a) + ' y ' + esc(b);
        h += '<div class="rt-card" style="border-left-color:' + colorOf(s.level) + '"><div class="t">' + lb[0] + ' ' + s.events.map(e => (LABEL[e.type] || ['', 'Aviso'])[1]).join(' + ') + '</div>' +
          '<div class="w">Km ' + Math.round(s.kmFrom) + (s.kmTo - s.kmFrom > 1 ? '–' + Math.round(s.kmTo) : '') + ' · ' + where + '</div>' +
          '<div class="w">Pasarías ~' + dayhh(s.etaFrom) + (s.etaTo - s.etaFrom > 20 * 60e3 ? ' a ' + dayhh(s.etaTo) : '') + '</div>' +
          '<div class="d">' + s.events.map(e => esc((window.plain||String)(e.detail))).join('<br>') + '</div><div class="tip">' + TIP + '</div></div>';
      });
    }
    out.innerHTML = h;
  }

  /* Quita la ruta del mapa, frena la actualización automática y olvida origen/destino. */
  const chip = el('button', 'rt-clear', '✕ Quitar ruta'); chip.type = 'button'; chip.style.display = 'none';
  (document.getElementById('mapWrap') || document.body).appendChild(chip);
  function clearRoute(reopen) {
    clearInterval(timer); timer = 0; busy = false; last = null; cache = null; seenKeys = {};
    group.clearLayers(); try { if (map.hasLayer(group)) map.removeLayer(group); } catch (e) { }
    R.from = null; R.to = null; save(); chip.style.display = 'none';
    try { map.getContainer().style.cursor = ''; } catch (e) { } root.__pickingRoute = false;
    if (reopen) { build(); toast('Ruta borrada'); }
    try { const p = cur(); if (p && p.lat != null) map.setView([p.lat, p.lon], Math.max(map.getZoom() > 11 ? 11 : map.getZoom(), 8)); } catch (e) { }
  }
  chip.onclick = () => { buzz(); clearRoute(false); toast('Ruta borrada'); };
  async function run(userTap) {
    if (busy) return;
    const out = $('rtOut');
    if (!R.from || !R.to) { if (out) out.innerHTML = '<div class="rt-warn">Elegí el origen y el destino.</div>'; return; }
    if (hav(R.from.lat, R.from.lon, R.to.lat, R.to.lon) < 2) { if (out) out.innerHTML = '<div class="rt-warn">El origen y el destino están muy cerca.</div>'; return; }
    busy = true; buzz(); if (out && userTap) out.innerHTML = '<div class="rt-hint">Calculando el camino y mirando el tiempo en cada tramo…</div>';
    try {
      const res = await analyze({ from: R.from, to: R.to, departMin: userTap ? (R.depart || 0) : Math.max(0, (R.depart || 0)), veh: R.veh }, typeof cfg !== 'undefined' ? cfg : null, cache);
      cache = { key: res.key, rt: res.rt }; last = res; render(res); draw(res); chip.style.display = '';
      // aviso al usuario si aparece un tramo de riesgo nuevo durante la actualización automática
      res.segs.forEach(s => { const k = s.events[0].type + '@' + Math.round(s.kmFrom / 30); if (!seenKeys[k]) { seenKeys[k] = 1; if (!userTap && s.level >= 2) { toast('⚠️ ' + (LABEL[s.events[0].type] || ['', 'Aviso'])[1] + ' en tu ruta, cerca de ' + s.from.place); buzz(); } } });
      clearInterval(timer); timer = setInterval(() => run(false), 10 * 60e3);
    } catch (e) {
      if (out) out.innerHTML = '<div class="rt-warn">No pude revisar la ruta: ' + esc((e && e.name === 'AbortError') ? 'tardó demasiado (revisá tu conexión)' : (e && e.message) || 'error') + '</div>';
    } finally { busy = false; }
  }

  // botón "Ruta" de la barra inferior (junto a Fincas). Plan Básica: se muestra qué incluye Pro.
  function lockedView() {
    body.innerHTML = '<div class="rt-ok" style="background:rgba(255,176,32,.12);border-color:rgba(255,176,32,.45)">🔒 <b>Avisos sobre tu ruta es una función Pro</b><br>Elegís origen y destino y la app te avisa de tormentas, granizo, viento y heladas en cada tramo, a la hora en que pasarías. Pensado para transporte y viajes.</div>' +
      '<button type="button" class="rt-go" id="rtPro">⭐ Ver la licencia Pro</button>';
    const b = $('rtPro'); if (b) b.onclick = () => { close(); if (root.openLicense) root.openLicense(); };
  }
  const openRoute = () => { buzz(); if (typeof root.cmCan === 'function' && !root.cmCan('route')) lockedView(); else build(); open(); };
  const rb = $('routeBtn');
  if (rb) rb.onclick = openRoute;
  root.__route = { open: openRoute, clear: clearRoute, state: () => ({ R, last }), run: () => run(true), api };
})(typeof window !== 'undefined' ? window : globalThis);
