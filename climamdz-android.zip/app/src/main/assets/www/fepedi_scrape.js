(function () {
  /* Se ejecuta dentro de la página de FePEDI (cargada en la pantalla oculta de la app).
     1) Si la página deja accesible su mapa (Leaflet), se leen directamente sus marcadores: posición exacta, red, estado,
        última lectura y, si lo trae, el resumen del día.
     2) Si no, se leen los marcadores dibujados en pantalla y se calcula su posición desde el mosaico del mapa
        (con el zoom y la escala reales del mosaico), y se tocan las más cercanas para leer el resumen del día. */
  var LAT = __LAT__, LON = __LON__, MAXKM = 60, MAXCLICK = 10;
  window.__fp = { done: false, stations: [], err: '', info: '' };
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  function tr(el) { var m = /translate3d\((-?[\d.]+)px,\s*(-?[\d.]+)px/.exec((el.style && el.style.transform) || ''); return m ? [+m[1], +m[2]] : null; }
  function f(s) { var m = /-?\d+(?:\.\d+)?/.exec(String(s || '').replace(',', '.')); return m ? +m[0] : null; }
  function km(a, b, c, d) { var R = 6371, p = Math.PI / 180, x = (c - a) * p, y = (d - b) * p, q = Math.sin(x / 2) * Math.sin(x / 2) + Math.cos(a * p) * Math.cos(c * p) * Math.sin(y / 2) * Math.sin(y / 2); return 2 * R * Math.asin(Math.sqrt(q)); }
  function grab(re, t) { var m = re.exec(t); return m ? f(m[1]) : null; }
  function ctext(c, ctx) { try { if (typeof c === 'function') c = c(ctx); if (c && c.nodeType) return c.textContent || ''; return String(c == null ? '' : c).replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' '); } catch (e) { return ''; } }
  function fillReading(o, tt) {
    var dm = /(\d{1,2})\/(\d{1,2})\/(\d{2,4})\s+(\d{1,2}):(\d{2})/.exec(tt);
    if (dm) { var yy = +dm[3]; if (yy < 100) yy += 2000; o.ms = Date.UTC(yy, +dm[2] - 1, +dm[1], +dm[4] + 3, +dm[5]); }   // hora de Argentina (UTC-3)
    o.t = grab(/\bT\s*:\s*(-?[\d.]+)/, tt); o.h = grab(/\bH\s*:\s*([\d.]+)/, tt); o.dp = grab(/rocio\s*:\s*(-?[\d.]+)/i, tt);
  }
  function fillDaily(o, txt) {
    var nm = /Estaci[oó]n:\s*(.+?)\s+(?:Tmin|T\s*:)/i.exec(txt); if (nm) o.name = nm[1];
    o.tmin = grab(/Tmin\s*:\s*(-?[\d.]+)/i, txt); o.tmax = grab(/Tmax\s*:\s*(-?[\d.]+)/i, txt); o.tprom = grab(/Tprom\s*:\s*(-?[\d.]+)/i, txt);
    o.hmin = grab(/Hmin\s*:\s*([\d.]+)/i, txt); o.hmax = grab(/Hmax\s*:\s*([\d.]+)/i, txt); o.hprom = grab(/Hprom\s*:\s*([\d.]+)/i, txt);
  }
  function netOf(src) { var k = /marker-icon-2x-([a-z]+)(-offline)?\.png/.exec(src || ''); return { net: k ? ({ gold: 'FEPEDI', orange: 'ISCAMEN', violet: 'COVIAR' }[k[1]] || k[1]) : '?', off: !!(k && k[2]) }; }
  function findMap() {
    var c = [window.map, window._map, window.mapa, window.mymap, window.mapa1], i;
    for (i = 0; i < c.length; i++) if (c[i] && typeof c[i].eachLayer === 'function' && typeof c[i].getZoom === 'function') return c[i];
    try { var ks = Object.keys(window); for (i = 0; i < ks.length; i++) { var v = window[ks[i]]; if (v && typeof v === 'object' && typeof v.eachLayer === 'function' && typeof v.getZoom === 'function' && typeof v.getCenter === 'function') return v; } } catch (e) { }
    return null;
  }
  (async function () {
    try {
      for (var w = 0; w < 24; w++) { if (document.querySelectorAll('img.leaflet-marker-icon').length >= 3) break; await sleep(500); }
      await sleep(1000);
      var st = [], method = 'dom', info = '';
      var M = findMap();
      if (M && window.L) {                                                   // ---- 1) desde el mapa de la página
        var ms = []; M.eachLayer(function (l) { if (window.L.Marker && l instanceof window.L.Marker) ms.push(l); });
        ms.forEach(function (l) {
          var ll = l.getLatLng(), src = (l.options && l.options.icon && l.options.icon.options && l.options.icon.options.iconUrl) || (l._icon && l._icon.getAttribute && l._icon.getAttribute('src')) || '';
          var tip = l.getTooltip && l.getTooltip(), pop = l.getPopup && l.getPopup();
          var o = netOf(src); o.lat = Math.round(ll.lat * 1e5) / 1e5; o.lon = Math.round(ll.lng * 1e5) / 1e5;
          fillReading(o, tip ? ctext(tip.getContent(), l) : '');
          if (pop) fillDaily(o, ctext(pop.getContent(), l));
          o.d = km(LAT, LON, o.lat, o.lon); st.push(o);
        });
        if (st.length >= 3) method = 'api';
      }
      if (method !== 'api') {                                                // ---- 2) desde lo dibujado en pantalla
        st = [];
        var conts = [].slice.call(document.querySelectorAll('.leaflet-tile-container')).map(function (c) {
          var m = /translate3d\((-?[\d.]+)px,\s*(-?[\d.]+)px[^)]*\)\s*(?:scale\((-?[\d.]+)\))?/.exec((c.style && c.style.transform) || '');
          return { el: c, a: m ? +m[1] : 0, b: m ? +m[2] : 0, s: (m && m[3]) ? +m[3] : 1, zi: +((c.style && c.style.zIndex) || 0), t: c.querySelector('img.leaflet-tile') };
        }).filter(function (c) { return c.t; }).sort(function (a, b) { return b.zi - a.zi; });
        if (!conts.length) throw new Error('sin mosaico del mapa');
        var C = conts[0], tm = /\/(\d+)\/(\d+)\/(\d+)\.png/.exec(C.t.src || ''), tp = tr(C.t);
        if (!tm || !tp) throw new Error('no se pudo ubicar el mapa');
        var z = +tm[1], s = C.s, n = 256 * Math.pow(2, z) * s, refx = +tm[2] * 256 * s, refy = +tm[3] * 256 * s, rpx = C.a + s * tp[0], rpy = C.b + s * tp[1];
        info = 'z' + z + (s !== 1 ? ' x' + s.toFixed(2) : '');
        [].slice.call(document.querySelectorAll('img.leaflet-marker-icon')).forEach(function (mk) {
          var p = tr(mk); if (!p) return;
          var wx = refx + (p[0] - rpx), wy = refy + (p[1] - rpy);
          var lon = wx / n * 360 - 180, lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * wy / n))) * 180 / Math.PI;
          var o = netOf(mk.getAttribute('src')); o.lat = Math.round(lat * 1e5) / 1e5; o.lon = Math.round(lon * 1e5) / 1e5; o.el = mk;
          var tipId = mk.getAttribute('aria-describedby'), tip = tipId ? document.getElementById(tipId) : null;
          fillReading(o, tip ? (tip.textContent || '') : '');
          o.d = km(LAT, LON, o.lat, o.lon); st.push(o);
        });
        var near = st.filter(function (q) { return !q.off && q.d <= MAXKM; }).sort(function (a, b) { return a.d - b.d; }).slice(0, MAXCLICK);
        for (var j = 0; j < near.length; j++) {
          try {
            near[j].el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
            var pc = null;
            for (var q = 0; q < 14; q++) { await sleep(120); pc = document.querySelector('.leaflet-popup-content'); if (pc && /Tmin|Estaci/i.test(pc.textContent || '')) break; }
            if (pc) fillDaily(near[j], (pc.textContent || '').replace(/\s+/g, ' '));
            var cb = document.querySelector('.leaflet-popup-close-button'); if (cb) cb.click();
            await sleep(80);
          } catch (e) { }
        }
      }
      var la = st.map(function (q) { return q.lat; }), lo = st.map(function (q) { return q.lon; });
      info = method + (info ? ' ' + info : '') + ' · ' + st.length + ' · lat ' + Math.min.apply(null, la).toFixed(2) + ' a ' + Math.max.apply(null, la).toFixed(2) + ' · lon ' + Math.min.apply(null, lo).toFixed(2) + ' a ' + Math.max.apply(null, lo).toFixed(2);
      st.forEach(function (q) { delete q.el; q.d = Math.round(q.d * 10) / 10; });
      window.__fp.stations = st; window.__fp.info = info;
    } catch (e) { window.__fp.err = String((e && e.message) || e).slice(0, 120); }
    window.__fp.done = true;
  })();
})();
