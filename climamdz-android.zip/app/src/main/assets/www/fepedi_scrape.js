(function () {
  /* Se ejecuta dentro de la página de FePEDI (cargada en la pantalla oculta de la app). Lee las estaciones que la propia página dibuja:
     posición (calculada desde el mosaico del mapa), red (por el color del marcador), estado y última lectura (cuadro flotante);
     y, de las más cercanas al usuario, el resumen del día que aparece al tocarlas. */
  var LAT = __LAT__, LON = __LON__, MAXKM = 60, MAXCLICK = 10;
  window.__fp = { done: false, stations: [], err: '' };
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  function tr(el) { var m = /translate3d\((-?[\d.]+)px,\s*(-?[\d.]+)px/.exec((el.style && el.style.transform) || ''); return m ? [+m[1], +m[2]] : null; }
  function f(s) { var m = /-?\d+(?:\.\d+)?/.exec(String(s || '').replace(',', '.')); return m ? +m[0] : null; }
  function km(a, b, c, d) { var R = 6371, p = Math.PI / 180, x = (c - a) * p, y = (d - b) * p, q = Math.sin(x / 2) * Math.sin(x / 2) + Math.cos(a * p) * Math.cos(c * p) * Math.sin(y / 2) * Math.sin(y / 2); return 2 * R * Math.asin(Math.sqrt(q)); }
  function grab(re, t) { var m = re.exec(t); return m ? f(m[1]) : null; }
  (async function () {
    try {
      for (var w = 0; w < 24; w++) { if (document.querySelectorAll('img.leaflet-marker-icon').length >= 3) break; await sleep(500); }
      await sleep(800);
      var tiles = [].slice.call(document.querySelectorAll('img.leaflet-tile')), zc = {};
      tiles.forEach(function (t) { var m = /\/(\d+)\/(\d+)\/(\d+)\.png/.exec(t.src || ''); if (m) zc[m[1]] = (zc[m[1]] || 0) + 1; });
      var zs = Object.keys(zc).sort(function (a, b) { return zc[b] - zc[a]; });
      if (!zs.length) throw new Error('sin mosaico del mapa');
      var z = +zs[0], ref = null;
      for (var i = 0; i < tiles.length && !ref; i++) {
        var m = /\/(\d+)\/(\d+)\/(\d+)\.png/.exec(tiles[i].src || ''), p = tr(tiles[i]);
        if (m && +m[1] === z && p) { var c = tiles[i].parentNode ? (tr(tiles[i].parentNode) || [0, 0]) : [0, 0]; ref = { x: +m[2], y: +m[3], px: p[0] + c[0], py: p[1] + c[1] }; }
      }
      if (!ref) throw new Error('no se pudo ubicar el mapa');
      var n = Math.pow(2, z) * 256, marks = [].slice.call(document.querySelectorAll('img.leaflet-marker-icon')), st = [];
      marks.forEach(function (mk) {
        var p = tr(mk); if (!p) return;
        var wx = ref.x * 256 + (p[0] - ref.px), wy = ref.y * 256 + (p[1] - ref.py);
        var lon = wx / n * 360 - 180, lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * wy / n))) * 180 / Math.PI;
        var k = /marker-icon-2x-([a-z]+)(-offline)?\.png/.exec(mk.getAttribute('src') || '');
        var tipId = mk.getAttribute('aria-describedby'), tip = tipId ? document.getElementById(tipId) : null, tt = tip ? (tip.textContent || '') : '';
        var o = { net: k ? ({ gold: 'FEPEDI', orange: 'ISCAMEN', violet: 'COVIAR' }[k[1]] || k[1]) : '?', off: !!(k && k[2]), lat: Math.round(lat * 1e5) / 1e5, lon: Math.round(lon * 1e5) / 1e5, el: mk };
        var dm = /(\d{1,2})\/(\d{1,2})\/(\d{2,4})\s+(\d{1,2}):(\d{2})/.exec(tt);
        if (dm) { var yy = +dm[3]; if (yy < 100) yy += 2000; o.ms = Date.UTC(yy, +dm[2] - 1, +dm[1], +dm[4] + 3, +dm[5]); }   // hora de Argentina (UTC-3)
        o.t = grab(/T\s*:\s*(-?[\d.]+)/, tt); o.h = grab(/\bH\s*:\s*([\d.]+)/, tt); o.dp = grab(/rocio\s*:\s*(-?[\d.]+)/i, tt);
        o.d = km(LAT, LON, o.lat, o.lon);
        st.push(o);
      });
      var near = st.filter(function (s) { return !s.off && s.d <= MAXKM; }).sort(function (a, b) { return a.d - b.d; }).slice(0, MAXCLICK);
      for (var j = 0; j < near.length; j++) {
        var s = near[j];
        try {
          s.el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
          var pc = null;
          for (var q = 0; q < 14; q++) { await sleep(120); pc = document.querySelector('.leaflet-popup-content'); if (pc && /Tmin|Estaci/i.test(pc.textContent || '')) break; }
          var txt = pc ? (pc.textContent || '').replace(/\s+/g, ' ') : '';
          var nm = /Estaci[oó]n:\s*(.+?)\s+(?:Tmin|T\s*:)/i.exec(txt); if (nm) s.name = nm[1];
          s.tmin = grab(/Tmin\s*:\s*(-?[\d.]+)/i, txt); s.tmax = grab(/Tmax\s*:\s*(-?[\d.]+)/i, txt); s.tprom = grab(/Tprom\s*:\s*(-?[\d.]+)/i, txt);
          s.hmin = grab(/Hmin\s*:\s*([\d.]+)/i, txt); s.hmax = grab(/Hmax\s*:\s*([\d.]+)/i, txt); s.hprom = grab(/Hprom\s*:\s*([\d.]+)/i, txt);
          var cb = document.querySelector('.leaflet-popup-close-button'); if (cb) cb.click();
          await sleep(80);
        } catch (e) { }
      }
      st.forEach(function (s) { delete s.el; s.d = Math.round(s.d * 10) / 10; });
      window.__fp.stations = st;
    } catch (e) { window.__fp.err = String((e && e.message) || e).slice(0, 120); }
    window.__fp.done = true;
  })();
})();
