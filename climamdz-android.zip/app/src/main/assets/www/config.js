/* Ajustes comerciales de TiempoMDZ — editá este archivo y recompilá.
   waNumber : WhatsApp que recibe los pedidos de licencia (formato internacional, sin + ni espacios).
   mpLinks  : links de pago de Mercado Pago. Estructura: mpLinks.B.M (Básica mensual), .B.S (semestral), .B.A (anual) y lo mismo en .P para Pro.
              Si un plan no tiene link, solo se ofrece pedirlo por WhatsApp.
   prices   : precio que se muestra en cada plan (texto libre, ej. "$2.500"). Vacío = no se muestra precio.
   limits   : qué incluye cada tipo de licencia. Los avisos OFICIALES del SMN se muestran siempre, en todos los planes.
              fincas       = cantidad máxima de fincas guardadas (además de "Mi ubicación")
              forecastDays = días del pronóstico extendido que se muestran
              frost / hail / approach / route = funciones exclusivas (true = incluida)
              Si el plan no incluye "hail", un granizo se avisa como "tormenta fuerte". */
window.CM_CFG = {
  brand: 'CodeMarket',
  waNumber: '5492615117220',
  mpLinks: { B: { M: '', S: '', A: '' }, P: { M: '', S: '', A: '' } },
  prices: { B: { M: '', S: '', A: '' }, P: { M: '', S: '', A: '' } },
  trialDays: 5,
  limits: {
    basic: { fincas: 2, forecastDays: 5, frost: false, hail: false, approach: false, route: false, voice: false },
    pro: { fincas: 20, forecastDays: 14, frost: true, hail: true, approach: true, route: true, voice: true }
  }
};
