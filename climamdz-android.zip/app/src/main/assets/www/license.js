/* Licencia: prueba gratis (con funciones Pro) y luego plan Básica o Pro, mensual / semestral / anual.
   La verificación real la hace la app nativa (clave firmada); esto es la pantalla. Solo corre dentro de la app Android. */
(function (g) {
  'use strict';
  if (!g.AndroidBridge) return;
  const $ = id => document.getElementById(id);
  const C = g.CM_CFG || {};
  const PLANS = [['M', 'Mensual', '1 mes'], ['S', 'Semestral', '6 meses'], ['A', 'Anual', '12 meses']];
  const J = (f, a) => { try { return JSON.parse(a === undefined ? AndroidBridge[f]() : AndroidBridge[f](a)); } catch (e) { return null; } };
  const TD = C.trialDays || 5;
  const TIERS = { B: 'Básica', P: 'Pro' };
  let st = null, shownTier = 'P';
  const isPro = () => !!st && st.state !== 'expired' && st.tier === 'pro';
  const tierName = () => st && st.tier === 'pro' ? 'PRO' : 'BÁSICA';
  // Tabla "qué incluye cada plan" (los números salen de la configuración, así que siempre coincide con lo que la app hace)
  function compareRows() {
    const lim = t => Object.assign({}, (g.TIER_LIMITS && g.TIER_LIMITS[t]) || {}, (C.limits && C.limits[t]) || {});
    const B = lim('basic'), P = lim('pro'), Y = '✅', N = '🔒';
    const yn = (b, p) => [b ? Y : N, p ? Y : N];
    return [
      ['Avisos oficiales del Servicio Meteorológico y de Contingencias Mendoza', Y, Y],
      ['Avisos de tormenta fuerte, viento fuerte y sismos', Y, Y],
      ['Sonido propio para cada tipo de aviso', Y, Y],
      ['Mapa con viento, nubes, lluvia y temperatura', Y, Y],
      ['Fincas o lugares guardados', String(B.fincas), String(P.fincas)],
      ['Pronóstico', B.forecastDays + ' días', P.forecastDays + ' días'],
      ['Aviso de heladas'].concat(yn(B.frost, P.frost)),
      ['Aviso específico de granizo' + (B.hail ? '' : ' (en Básica avisa como "tormenta fuerte")')].concat(yn(B.hail, P.hail)),
      ['Tormenta en camino, con minutos de llegada'].concat(yn(B.approach, P.approach)),
      ['Avisos sobre tu ruta, para viajes y transporte'].concat(yn(B.route, P.route))
    ];
  }
  function compareTable() {
    const wrap = document.createElement('div'); wrap.className = 'lic-cmp';
    const head = document.createElement('div'); head.className = 'cr ch';
    head.innerHTML = '<span>Qué incluye cada plan</span><span>Básica</span><span class="pro">Pro ⭐</span>';
    wrap.appendChild(head);
    compareRows().forEach(r => {
      const d = document.createElement('div'); d.className = 'cr';
      const a = document.createElement('span'), b = document.createElement('span'), c = document.createElement('span');
      a.textContent = r[0]; b.textContent = r[1]; c.textContent = r[2]; c.className = 'pro';
      d.appendChild(a); d.appendChild(b); d.appendChild(c); wrap.appendChild(d);
    });
    return wrap;
  }

  function left(ms) {
    const m = Math.max(0, Math.floor(ms / 60000)), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60);
    return d >= 1 ? d + ' d ' + h + ' h' : h >= 1 ? h + ' h ' + (m % 60) + ' min' : (m % 60) + ' min';
  }
  const fdate = ms => new Date(ms).toLocaleDateString('es-AR');

  function waLink(plan, tier) {
    const p = PLANS.find(x => x[0] === plan);
    const t = 'Hola ' + (C.brand || '') + ', quiero la licencia ' + TIERS[tier].toUpperCase() + ' ' + p[1].toUpperCase() + ' de TiempoMDZ. Mi ID de celular es: ' + st.device;
    return 'https://wa.me/' + (C.waNumber || '') + '?text=' + encodeURIComponent(t);
  }

  function paintBtn() {
    const b = $('licBtn'), tag = $('licTag'); if (!st) return;
    let txt, cls;
    if (st.state === 'licensed') { txt = tierName() + ' · ' + left(st.msLeft).split(' ').slice(0, 2).join(' '); cls = st.msLeft < 7 * 864e5 ? 'warn' : (st.tier === 'pro' ? 'pro' : 'ok'); }
    else if (st.state === 'trial') { txt = 'PRUEBA · ' + left(st.msLeft).split(' ').slice(0, 2).join(' '); cls = 'warn'; }
    else { txt = 'VENCIDA'; cls = 'bad'; }
    if (tag) { tag.style.display = 'inline-flex'; tag.className = 'lic-tag ' + cls; tag.textContent = txt; tag.title = 'Tu licencia'; }
    if (b) b.textContent = '🔑 ' + txt;
  }

  function paintModal() {
    if (!st) return;
    const blocked = st.state === 'expired', box = $('licStatus');
    $('licClose').style.display = blocked ? 'none' : '';
    $('licModal').classList.toggle('lock', blocked);
    $('licSos').style.display = blocked ? '' : 'none';
    let t, c;
    if (st.state === 'licensed') { t = '✅ Licencia ' + tierName() + ' ' + (st.plan === 'M' ? 'mensual' : st.plan === 'S' ? 'semestral' : st.plan === 'A' ? 'anual' : '') + ' activa · vence el ' + fdate(st.expiry) + ' (' + left(st.msLeft) + ')'; c = 'ok'; }
    else if (st.state === 'trial') { t = '🎁 Prueba gratis con todas las funciones Pro: te quedan ' + left(st.msLeft) + '. Después necesitás una licencia Básica o Pro para seguir recibiendo avisos.'; c = 'warn'; }
    else if (st.reason === 'clock') { t = '⏰ La fecha/hora del celular está atrasada. Corregila (Ajustes → Fecha y hora automática) para seguir.'; c = 'bad'; }
    else { t = st.reason === 'license' ? '⛔ Tu licencia venció el ' + fdate(st.expiry) + '. Renovala para volver a recibir avisos.' : '⛔ Terminó la prueba gratis de ' + TD + ' días. Elegí un plan para seguir recibiendo avisos.'; c = 'bad'; }
    box.textContent = t; box.className = 'msg ' + c;
    $('licDev').textContent = st.device;
  }

  function buildPlans() {
    const box = $('licPlans'); box.innerHTML = '';
    const tabs = document.createElement('div'); tabs.className = 'lic-tabs';
    ['B', 'P'].forEach(t => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'lic-tab' + (t === shownTier ? ' on' : '');
      b.textContent = t === 'P' ? 'Pro ⭐' : 'Básica'; b.onclick = () => { hap(); shownTier = t; buildPlans(); };
      tabs.appendChild(b);
    });
    box.appendChild(compareTable());
    const pick = document.createElement('p'); pick.className = 'lic-pick'; pick.textContent = 'Elegí el plan que querés pedir:';
    box.appendChild(pick); box.appendChild(tabs);
    const note = document.createElement('p'); note.className = 'note'; note.textContent = 'Los avisos oficiales del SMN se muestran siempre, con cualquier licencia. Durante la prueba gratis tenés todo lo de Pro.';
    box.appendChild(note);
    PLANS.forEach(([k, name, dur]) => {
      const d = document.createElement('div'); d.className = 'lp';
      const price = (C.prices && C.prices[shownTier] && C.prices[shownTier][k]) || '';
      d.innerHTML = '<div class="lpt"><b></b><small></small></div><div class="lpb"></div>';
      d.querySelector('b').textContent = TIERS[shownTier] + ' ' + name.toLowerCase() + (price ? ' · ' + price : '');
      d.querySelector('small').textContent = dur;
      const bx = d.querySelector('.lpb'), link = C.mpLinks && C.mpLinks[shownTier] && C.mpLinks[shownTier][k];
      if (link) { const a = document.createElement('button'); a.className = 'btn g'; a.textContent = '💳 Pagar'; a.onclick = () => { hap(); window.open(link, '_blank'); }; bx.appendChild(a); }
      const w = document.createElement('button'); w.className = 'btn'; w.textContent = '💬 Pedir por WhatsApp';
      w.onclick = () => { hap(); window.open(waLink(k, shownTier), '_blank'); }; bx.appendChild(w);
      box.appendChild(d);
    });
  }

  function refresh() {
    const s = J('licenseStatus'); if (!s) return;
    const was = st && st.state, wasTier = g.CM_TIER; st = s;
    g.CM_TIER = (s.state !== 'expired' && s.tier === 'pro') ? 'pro' : 'basic';
    if (wasTier !== g.CM_TIER) { try { g.dispatchEvent(new Event('cm-tier')); } catch (e) { } }
    paintBtn(); paintModal();
    if (s.state === 'expired' && was !== 'expired') open();
    if (s.state !== 'expired' && was === 'expired') $('licModal').classList.remove('active');
  }
  g.openLicense = () => { refresh(); open(); };
  function open() { buildPlans(); paintModal(); $('licModal').classList.add('active'); }

  function init() {
    const openIt = () => { hap(); refresh(); open(); };
    $('licBtn').onclick = openIt; if ($('licTag')) $('licTag').onclick = openIt;
    $('licClose').onclick = () => $('licModal').classList.remove('active');
    $('licSos').onclick = () => { if (typeof openSOS === 'function') openSOS(''); };
    $('licCopy').onclick = () => { hap(); AndroidBridge.copyText(st.device); fb($('licCopy'), 'ok', '✔ Copiado', 1800); };
    $('licPaste').onclick = () => { hap(); const t = AndroidBridge.readClipboard(); if (t) { $('licKey').value = t.trim(); fb($('licPaste'), 'ok', '✔ Pegado', 1500); } else fb($('licPaste'), 'warn', 'Portapapeles vacío', 1800); };
    $('licGo').onclick = () => {
      const k = $('licKey').value.trim(), b = $('licGo');
      if (!k) { fb(b, 'warn', 'Pegá la clave', 1800); return; }
      hap(); fb(b, 'busy', '⏳ Verificando…');
      setTimeout(() => {
        const r = J('activateLicense', k) || { ok: false, msg: 'No se pudo verificar.' };
        const m = $('licMsg'); m.textContent = r.msg; m.className = 'msg ' + (r.ok ? 'ok' : 'bad');
        fb(b, r.ok ? 'ok' : 'bad', r.ok ? '✔ Activada' : '✖ No válida', 2500);
        if (r.ok) { $('licKey').value = ''; refresh(); if (st.state !== 'expired') setTimeout(() => $('licModal').classList.remove('active'), 1800); }
      }, 400);
    };
    refresh(); setInterval(refresh, 30000);
    const r0 = g.onNativeResume; g.onNativeResume = () => { if (r0) r0(); refresh(); };
  }
  g.addEventListener('load', init);
})(window);
