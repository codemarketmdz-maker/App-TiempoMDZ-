package ar.mdz.clima

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/**
 * El INPRES arma su tabla "Últimos 50 sismos" con JavaScript, así que el HTML pelado viene vacío.
 * Se abre la página en un WebView oculto, se espera a que aparezca la tabla y se leen las filas.
 * Debe llamarse desde el hilo principal.
 */
object InpresScraper {
    private val URLS = listOf(
        "https://www.inpres.gob.ar/seismology/xultimos",
        "https://contenidos.inpres.gob.ar/sismologia/xultimos"
    )
    private var busy = false

    private const val JS = "(function(){var r=[];function grab(d){try{d.querySelectorAll('tr').forEach(function(tr){var c=[];" +
        "for(var i=0;i<tr.children.length;i++){c.push((tr.children[i].innerText||tr.children[i].textContent||'').replace(/\\s+/g,' ').trim())}" +
        "r.push(c)})}catch(e){}}grab(document);var fr=document.querySelectorAll('iframe,frame');" +
        "for(var k=0;k<fr.length;k++){try{grab(fr[k].contentDocument)}catch(e){}}" +
        "return JSON.stringify({rows:r,title:document.title,frames:fr.length,len:document.documentElement.innerHTML.length})})()"

    fun run(ctx: Context, done: (String) -> Unit) {
        if (busy) {
            done("{\"error\":\"ya se está consultando\"}")
            return
        }
        busy = true
        val handler = Handler(Looper.getMainLooper())
        tryUrl(ctx.applicationContext, handler, 0, "", done)
    }

    private fun countRows(rows: JSONArray): Int {
        var n = 0
        for (i in 0 until rows.length()) {
            val r = rows.optJSONArray(i) ?: continue
            if (r.length() >= 6 && r.optString(0).matches(Regex("\\d{1,3}")) && r.optString(1).matches(Regex("\\d{1,2}/\\d{1,2}.*"))) n++
        }
        return n
    }

    private fun tryUrl(ctx: Context, handler: Handler, idx: Int, lastErr: String, done: (String) -> Unit) {
        if (idx >= URLS.size) {
            busy = false
            done(JSONObject().put("error", lastErr.ifEmpty { "sin datos" }).toString())
            return
        }
        val wv = WebView(ctx)
        var finished = false
        var tries = 0
        var rowsSeen = 0
        var info = ""
        lateinit var poll: Runnable
        fun close() {
            handler.removeCallbacksAndMessages(null)
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (e: Exception) {
            }
        }
        fun fail(msg: String) {
            if (finished) return
            finished = true
            close()
            tryUrl(ctx, handler, idx + 1, msg, done)
        }
        poll = Runnable {
            if (finished) return@Runnable
            wv.evaluateJavascript(JS) { res ->
                if (finished) return@evaluateJavascript
                try {
                    val str = JSONTokener(res).nextValue() as? String ?: ""
                    val o = JSONObject(str)
                    val rows = o.getJSONArray("rows")
                    rowsSeen = rows.length()
                    info = "título «" + o.optString("title").take(40) + "», " + o.optInt("frames") + " marcos, " + o.optInt("len") + " caracteres"
                    if (countRows(rows) >= 3) {
                        finished = true
                        close()
                        busy = false
                        done(JSONObject().put("rows", rows).toString())
                        return@evaluateJavascript
                    }
                } catch (e: Exception) {
                }
                tries++
                if (tries < 16) handler.postDelayed(poll, 700) else fail("abrió pero sin tabla de sismos (" + rowsSeen + " filas; " + info + ")")
            }
        }
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (!finished && tries == 0) handler.postDelayed(poll, 800)
            }

            override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request != null && request.isForMainFrame) fail("no abrió la página (" + (error?.description ?: "error") + ")")
            }
        }
        handler.postDelayed({ fail("tardó demasiado" + (if (info.isNotEmpty()) " (" + info + ")" else "")) }, 12000)
        wv.loadUrl(URLS[idx])
    }
}
