package ar.mdz.clima

import android.content.Context
import android.content.SharedPreferences

object Store {
    fun p(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("clima", Context.MODE_PRIVATE)

    /** ¿La vigilancia en segundo plano está encendida? (por defecto sí) */
    fun monitorOn(ctx: Context): Boolean = p(ctx).getBoolean("monitor_on", true)

    /** Cada cuántos minutos revisa en segundo plano (5, 10, 15, 30 o 60). */
    fun intervalMin(ctx: Context): Int {
        val m = p(ctx).getInt("interval_min", 5)
        return if (m in intArrayOf(5, 10, 15, 30, 60)) m else 5
    }

    /** Minutos sin internet después de los cuales se avisa que la vigilancia está ciega (15, 30, 60 o 120). */
    fun outageMin(ctx: Context): Int {
        val m = p(ctx).getInt("outage_min", 30)
        return if (m in intArrayOf(15, 30, 60, 120)) m else 30
    }
}
