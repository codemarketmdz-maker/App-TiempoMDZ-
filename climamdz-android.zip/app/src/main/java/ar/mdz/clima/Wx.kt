package ar.mdz.clima

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import java.util.Calendar

/** Estado del cielo para la notificación fija: texto, ícono de barra de estado e ícono grande en color. */
object Wx {
    /** Clave del ícono según el código WMO (Open-Meteo), la lluvia medida y la nubosidad. */
    fun key(code: Int, precip: Double, cloud: Int, day: Boolean): String = when {
        code in 95..99 -> "storm"
        code in 71..77 || code == 85 || code == 86 -> "snow"
        code in 51..67 || code in 80..82 || precip >= 0.1 -> "rain"
        code == 45 || code == 48 -> "fog"
        code == 0 || code == 1 || (code < 0 && cloud < 45) -> if (day) "sun" else "moon"
        code == 2 || (code < 0 && cloud < 75) -> if (day) "partly" else "partly_night"
        else -> "cloud"
    }

    fun text(code: Int, precip: Double, cloud: Int, day: Boolean): String = when {
        code in 95..99 -> "Tormenta eléctrica"
        code in 71..77 || code == 85 || code == 86 -> "Nevando"
        code == 65 || code == 67 -> "Lluvias fuertes"
        code == 82 -> "Chubascos fuertes"
        code == 80 || code == 81 -> "Chubascos"
        code in 51..57 -> "Llovizna"
        code in 61..66 -> "Lluvia"
        precip >= 0.1 -> "Lloviendo"
        code == 45 || code == 48 -> "Niebla"
        code == 0 || (code < 0 && cloud < 20) -> if (day) "Soleado" else "Despejado"
        code == 1 || (code < 0 && cloud < 45) -> if (day) "Mayormente soleado" else "Mayormente despejado"
        code == 2 || (code < 0 && cloud < 75) -> "Parcialmente nublado"
        else -> "Nublado"
    }

    /** Si el dato no trae día/noche: aproximación por hora según la estación (verano 6–20, invierno 7–18). */
    fun isDayNow(): Boolean {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR_OF_DAY)
        val summer = c.get(Calendar.MONTH).let { it >= 9 || it <= 2 }
        return if (summer) h in 6..20 else h in 7..18
    }

    fun smallRes(key: String): Int = when (key) {
        "sun" -> R.drawable.ic_wx_sun
        "moon" -> R.drawable.ic_wx_moon
        "partly" -> R.drawable.ic_wx_partly
        "partly_night" -> R.drawable.ic_wx_partly_night
        "rain" -> R.drawable.ic_wx_rain
        "storm" -> R.drawable.ic_wx_storm
        "fog" -> R.drawable.ic_wx_fog
        "snow" -> R.drawable.ic_wx_snow
        else -> R.drawable.ic_wx_cloud
    }

    private fun emoji(key: String): String = when (key) {
        "sun" -> "☀️"
        "moon" -> "🌙"
        "partly" -> "⛅"
        "partly_night" -> "🌙☁️"
        "rain" -> "🌧️"
        "storm" -> "⛈️"
        "fog" -> "🌫️"
        "snow" -> "❄️"
        else -> "☁️"
    }

    /** Ícono grande en color (emoji del sistema dibujado en un cuadro). */
    fun bitmap(key: String): Bitmap {
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val txt = emoji(key)
        p.textSize = size * 0.78f
        val w = p.measureText(txt)
        if (w > size * 0.92f) p.textSize = p.textSize * (size * 0.92f) / w
        val x = (size - p.measureText(txt)) / 2f
        val y = size / 2f - (p.descent() + p.ascent()) / 2f
        cv.drawText(txt, x, y, p)
        return bmp
    }
}
