package ar.mdz.clima

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Servicio en primer plano: cada ~5 min revisa el clima, el satélite y los sismos
 * (con la misma lógica de la app web, corriendo en un WebView invisible) y dispara la alarma.
 */
class MonitorService : Service() {

    companion object {
        @Volatile
        var instance: MonitorService? = null
        const val ACTION_TICK = "ar.mdz.clima.TICK"

        fun intervalMs(ctx: Context): Long = Store.intervalMin(ctx) * 60L * 1000L

        fun start(ctx: Context) {
            if (!Store.monitorOn(ctx)) return // apagada a propósito: no se reinicia sola
            ctx.startForegroundService(Intent(ctx, MonitorService::class.java))
        }

        /** Apaga la vigilancia: cancela la próxima revisión y detiene el servicio (se va la notificación fija). */
        fun stopMonitoring(ctx: Context) {
            try {
                val am = ctx.getSystemService(AlarmManager::class.java)
                val pi = PendingIntent.getBroadcast(
                    ctx, 7, Intent(ctx, TickReceiver::class.java).setAction(ACTION_TICK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                am.cancel(pi)
                Health.recordNext(ctx, 0L)
            } catch (e: Exception) {
            }
            try {
                instance?.stopSelf()
                ctx.stopService(Intent(ctx, MonitorService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var web: WebView? = null
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var busy = false
    private var wl: PowerManager.WakeLock? = null
    private var lm: LocationManager? = null

    private val watchdog = Runnable {
        // la revisión no contestó a tiempo: cuenta como falla
        Health.recordFail(this)
        updateText("Sin respuesta a las " + hhmm() + " · reintenta en " + Store.intervalMin(this) + " min")
        finishCheck()
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        loadWx()
        Alarm.ensureChannels(this)
        startFg("Iniciando…")
        startLocation()
        registerNet()
        // si la app está abierta ya está analizando: no competir con ella por red y CPU
        handler.postDelayed({ runCheck() }, if (MainActivity.visible) 90000L else 4000L)
    }

    // ---------- sin internet: no se gasta batería reintentando; al volver la conexión se revisa enseguida ----------
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var wasOffline = false

    private fun registerNet() {
        try {
            val cm = getSystemService(ConnectivityManager::class.java)
            wasOffline = !Health.hasNet(this)
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onLost(network: Network) {
                    handler.post { wasOffline = true }
                }

                override fun onAvailable(network: Network) {
                    handler.post {
                        if (wasOffline) {
                            wasOffline = false
                            // vuelve la conexión: se revisa ya, sin esperar el próximo turno
                            handler.postDelayed({ if (Store.monitorOn(this@MonitorService)) runCheck() }, 5000L)
                        }
                    }
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (e: Exception) {
        }
    }

    private fun unregisterNet() {
        try {
            val cb = netCb
            if (cb != null) getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
        } catch (e: Exception) {
        }
        netCb = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Store.monitorOn(this)) { startFg("Apagada"); stopSelf(); return START_NOT_STICKY }
        startFg("Vigilando tu ubicación y tus fincas")
        if (intent != null && intent.action == ACTION_TICK) runCheck()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        try {
            lm?.removeUpdates(locListener)
        } catch (e: Exception) {
        }
        unregisterNet()
        destroyWeb()
        releaseWl()
        super.onDestroy()
    }

    // ---------- notificación fija ----------
    // Último clima conocido (lo informa la revisión de fondo) para mostrarlo en la notificación fija
    private var wx: JSONObject? = null

    private fun loadWx() {
        try {
            val j = Store.p(this).getString("wx", null)
            if (j != null) wx = JSONObject(j)
        } catch (e: Exception) {
        }
    }

    private fun wxCompact(): String? {
        val w = wx ?: return null
        val sb = StringBuilder()
        sb.append(w.optString("icon")).append(' ').append(w.optInt("t")).append("° ").append(w.optString("sky"))
        if (w.optInt("cloud", -1) >= 0) sb.append(" · Nubes ").append(w.optInt("cloud")).append('%')
        val b = w.optInt("bolts", -1)
        sb.append(" · ⚡ ").append(if (b >= 0) b.toString() else "–")
        sb.append(" · Nivel ").append(w.optInt("level"))
        return sb.toString()
    }

    private fun wxDetail(status: String): String {
        val w = wx ?: return status
        val sb = StringBuilder()
        sb.append(w.optString("icon")).append(' ').append(w.optString("sky")).append(" · ").append(w.optInt("t")).append("° en ").append(w.optString("place")).append('\n')
        if (w.optInt("cloud", -1) >= 0) sb.append("Nubes ").append(w.optInt("cloud")).append("% · Humedad ").append(w.optInt("hum")).append("%\n")
        sb.append("Viento ").append(w.optInt("wind")).append(" km/h (ráfagas ").append(w.optInt("gust")).append(")")
        if (w.optDouble("rain", 0.0) > 0) sb.append(" · Lluvia ").append(w.optDouble("rain")).append(" mm")
        sb.append('\n')
        val b = w.optInt("bolts", -1)
        sb.append("⚡ Rayos (10 min, 50 km): ").append(if (b >= 0) b.toString() else "sin datos")
        if (b > 0 && !w.isNull("nearKm")) sb.append(" · el más cerca a ").append(w.optInt("nearKm")).append(" km")
        sb.append('\n')
        sb.append("Nivel ").append(w.optInt("level")).append(" · ").append(w.optString("levelTxt")).append('\n')
        sb.append(status)
        return sb.toString()
    }

    private fun buildFg(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, Alarm.CH_MON)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("TiempoMDZ vigilando")
            .setContentText(wxCompact() ?: text)
            .setSubText(if (wx != null) text else null)
            .setStyle(Notification.BigTextStyle().bigText(wxDetail(text)))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun startFg(text: String) {
        val n = buildFg(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun updateText(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(1, buildFg(text))
        } catch (e: Exception) {
        }
    }

    private fun hhmm(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    // ---------- ubicación ----------
    private fun hasLocPerm(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startLocation() {
        try {
            if (!hasLocPerm()) return
            val m = getSystemService(LocationManager::class.java)
            lm = m
            if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 300000L, 300f, locListener)
            }
        } catch (e: Exception) {
        }
    }

    /** Reemplaza la ubicación guardada ("gps") por la última conocida del celular. */
    private fun applyNativeLocation(locs: JSONArray) {
        try {
            if (!hasLocPerm()) return
            val m = getSystemService(LocationManager::class.java)
            var best: Location? = null
            for (p in m.getProviders(true)) {
                val l: Location? = try {
                    m.getLastKnownLocation(p)
                } catch (e: SecurityException) {
                    null
                }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            if (best == null) return
            if (System.currentTimeMillis() - best.time > 6L * 3600L * 1000L) return
            for (i in 0 until locs.length()) {
                val o = locs.getJSONObject(i)
                if (o.optString("id") == "gps") {
                    o.put("lat", best.latitude)
                    o.put("lon", best.longitude)
                }
            }
        } catch (e: Exception) {
        }
    }

    // ---------- ciclo de revisión ----------
    /** Cambió el intervalo: reprograma la próxima revisión con el tiempo nuevo. */
    fun reschedule() { scheduleNext() }

    private fun scheduleNext() {
        try {
            Health.recordNext(this, System.currentTimeMillis() + intervalMs(this))
            val am = getSystemService(AlarmManager::class.java)
            val pi = PendingIntent.getBroadcast(
                this, 7,
                Intent(this, TickReceiver::class.java).setAction(ACTION_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + intervalMs(this),
                pi
            )
        } catch (e: Exception) {
        }
    }

    fun runCheck() {
        scheduleNext()
        if (busy) return
        val prefs = Store.p(this)
        val stateJson = prefs.getString("state", null)
        if (stateJson == null) {
            updateText("Abrí la app una vez para elegir tus ubicaciones")
            return
        }
        if (!License.isActive(this)) {
            updateText("Licencia vencida · abrí la app para renovar")
            return
        }
        if (MainActivity.visible) {
            updateText("App abierta · " + hhmm())
            return
        }
        busy = true
        acquireWl()
        try {
            val st = JSONObject(stateJson)
            val locs = st.optJSONArray("locs") ?: JSONArray()
            applyNativeLocation(locs)
            val arg = JSONObject()
            arg.put("cfg", st.optJSONObject("cfg") ?: JSONObject())
            arg.put("locs", locs)
            arg.put("tier", License.status(this).optString("tier", "basic"))
            arg.put("notified", JSONObject(prefs.getString("notified", "{}") ?: "{}"))
            val js = "runCheck(" + arg.toString() + ")"
            withWeb { w -> w.evaluateJavascript(js, null) }
            handler.postDelayed(watchdog, 70000L)
        } catch (e: Exception) {
            Health.recordFail(this)
            finishCheck()
        }
    }

    private fun acquireWl() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            val l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clima:revision")
            l.acquire(90000L)
            wl = l
        } catch (e: Exception) {
        }
    }

    private fun releaseWl() {
        try {
            val l = wl
            if (l != null && l.isHeld) l.release()
        } catch (e: Exception) {
        }
        wl = null
    }

    private fun finishCheck() {
        handler.removeCallbacks(watchdog)
        busy = false
        destroyWeb()
        releaseWl()
    }

    // ---------- WebView invisible ----------
    private fun createWeb(): WebView {
        val w = WebView(applicationContext)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        w.addJavascriptInterface(BgBridge(), "AndroidBg")
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                OfficialProxy.intercept(request)?.let { return it }
                return loader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                ready = true
                val p = pending
                pending = null
                if (p != null) p()
            }
        }
        ready = false
        w.loadUrl("https://appassets.androidplatform.net/assets/www/bg.html")
        return w
    }

    private fun withWeb(job: (WebView) -> Unit) {
        val w = web ?: createWeb().also { web = it }
        if (ready) job(w) else pending = { job(w) }
    }

    private fun destroyWeb() {
        pending = null
        ready = false
        try {
            web?.destroy()
        } catch (e: Exception) {
        }
        web = null
    }

    inner class BgBridge {
        @JavascriptInterface
        fun onResult(json: String) {
            handler.post { handleResult(json) }
        }
    }

    private fun handleResult(json: String) {
        try {
            val r = JSONObject(json)
            val prefs = Store.p(this)
            val notified = r.optJSONObject("notified")
            prefs.edit().putString("notified", if (notified != null) notified.toString() else "{}").apply()
            val st = JSONObject(prefs.getString("state", "{}") ?: "{}")
            val cfg = st.optJSONObject("cfg")
            val sound = cfg?.optBoolean("sound", true) ?: true
            val vib = cfg?.optBoolean("vibrate", true) ?: true
            val alerts = r.optJSONArray("alerts") ?: JSONArray()
            val list = ArrayList<JSONObject>()
            for (i in 0 until alerts.length()) list.add(alerts.getJSONObject(i))
            list.sortBy { Alarm.priority(it.optString("type")) } // el más urgente va último: es el que suena
            for (a in list) {
                val nid = (a.optString("tag").hashCode() and 0x7fffffff) % 100000 + 10
                Alarm.fire(this, nid, a.optString("title"), a.optString("body"), a.optString("type"), sound, vib, a.optString("say"))
            }
            r.optJSONObject("wx")?.let { wx = it; prefs.edit().putString("wx", it.toString()).apply() }
            if (r.optBoolean("ok")) {
                Health.recordOk(this)
                var t = "Última revisión " + hhmm()
                if (alerts.length() > 0) t += " · " + alerts.length() + " aviso(s)"
                updateText(t)
            } else {
                Health.recordFail(this)
                val why = if (Health.hasNet(this)) "Sin datos" else "Sin internet"
                updateText(why + " a las " + hhmm() + " · reintenta en " + Store.intervalMin(this) + " min")
            }
        } catch (e: Exception) {
        }
        finishCheck()
    }
}
