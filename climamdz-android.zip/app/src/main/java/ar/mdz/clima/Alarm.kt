package ar.mdz.clima

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Alerta fuerte: notificación de pantalla completa + sonido por el canal de ALARMA + vibración.
 *
 * Patrón: suena y vibra 5 s, pausa 20 s, y repite hasta que la persona la lea o la abra
 * (botón Detener, tocar la notificación, deslizarla, abrir la app). Tope de seguridad: 1 hora.
 */
object Alarm {
    const val CH_ALERT = "alertas_v2"
    private const val CH_ALERT_OLD = "alertas_urgentes"
    const val CH_MON = "vigilancia"
    const val CH_STATUS = "estado_conexion"

    const val BUZZ_MS = 5000L
    const val PAUSE_MS = 20000L
    private const val MAX_MS = 60L * 60L * 1000L

    private var player: MediaPlayer? = null
    private var preview: MediaPlayer? = null
    private var appCtx: Context? = null
    private var ringLock: PowerManager.WakeLock? = null
    private var wantSound = false
    private var wantVib = false
    private var wantType = "stormStrong"

    @Volatile
    private var ringing = false
    private val handler = Handler(Looper.getMainLooper())
    private val buzzOn = Runnable { buzzStart() }
    private val buzzOff = Runnable { buzzStop() }
    private val giveUp = Runnable { silence() }
    private val previewOff = Runnable { stopPreview() }

    fun isRinging(): Boolean = ringing

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)

        val mon = NotificationChannel(CH_MON, "Vigilancia en segundo plano", NotificationManager.IMPORTANCE_LOW)
        mon.setShowBadge(false)
        nm.createNotificationChannel(mon)

        val st = NotificationChannel(CH_STATUS, "Estado de la conexión", NotificationManager.IMPORTANCE_DEFAULT)
        st.description = "Avisa si la app dejó de poder revisar el clima (sin internet, etc.)"
        nm.createNotificationChannel(st)

        // El canal viejo vibraba por su cuenta: se reemplaza para que la vibración la controle la alarma (5 s / 20 s)
        if (nm.getNotificationChannel(CH_ALERT_OLD) != null) nm.deleteNotificationChannel(CH_ALERT_OLD)

        val existing = nm.getNotificationChannel(CH_ALERT)
        if (existing != null && nm.isNotificationPolicyAccessGranted && !existing.canBypassDnd()) {
            nm.deleteNotificationChannel(CH_ALERT)
        }
        if (nm.getNotificationChannel(CH_ALERT) == null) {
            val ch = NotificationChannel(CH_ALERT, "Alertas de clima y sismos", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Avisos urgentes de tormenta, granizo, viento, Zonda y sismos"
            ch.enableVibration(false)
            ch.setSound(null, null)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            ch.setBypassDnd(true)
            nm.createNotificationChannel(ch)
        }
    }

    fun fire(ctx: Context, id: Int, title: String, body: String, type: String, sound: Boolean, vibrate: Boolean, say: String = "") {
        val app = ctx.applicationContext
        appCtx = app
        ensureChannels(app)
        val nm = app.getSystemService(NotificationManager::class.java)
        val pf = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val alertIntent = Intent(app, AlertActivity::class.java)
        alertIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        alertIntent.putExtra("title", title)
        alertIntent.putExtra("body", body)
        alertIntent.putExtra("type", type)
        val fullPi = PendingIntent.getActivity(app, id, alertIntent, pf)

        val openIntent = Intent(app, MainActivity::class.java)
        openIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        openIntent.putExtra("alert", type)
        val openPi = PendingIntent.getActivity(app, id + 1000, openIntent, pf)

        val stopPi = PendingIntent.getBroadcast(app, 1, Intent(app, StopReceiver::class.java), pf)
        val dialPi = PendingIntent.getActivity(app, 2, Intent(Intent.ACTION_DIAL, Uri.parse("tel:911")), pf)

        val first = body.lines().firstOrNull() ?: ""
        val n = Notification.Builder(app, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(first)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .setDeleteIntent(stopPi) // deslizarla = "la leí": corta la alarma
            .setFullScreenIntent(fullPi, true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPi)
            .addAction(android.R.drawable.ic_menu_call, "Llamar 911", dialPi)
            .build()
        nm.notify(id, n)

        startAlarm(app, sound, vibrate, type)
        wakeScreen(app)
        scheduleSpeech(app, say, sound)
    }

    // ---------- voz: solo el aviso más urgente (el último que se dispara) habla, después del sonido ----------
    private var speechRun: Runnable? = null

    private fun scheduleSpeech(app: Context, say: String, sound: Boolean) {
        speechRun?.let { handler.removeCallbacks(it) }
        speechRun = null
        if (say.isBlank() || !Voice.enabled(app)) return
        Voice.prepare(app) // se va preparando mientras suena el sonido
        val r = Runnable { Voice.speak(app, say) }
        speechRun = r
        handler.postDelayed(r, if (sound) 5600L else 300L)
    }

    private fun cancelSpeech() {
        speechRun?.let { handler.removeCallbacks(it) }
        speechRun = null
        Voice.stop()
    }

    // ---------- sonidos propios (uno por tipo de aviso, dentro de la app) ----------
    private val SOUND_TYPES = setOf("hail", "stormStrong", "stormWeak", "stormApproach", "wind", "zonda", "quake", "frost")

    /** Prioridad para decidir cuál suena si llegan varios avisos juntos (mayor = más urgente). */
    fun priority(type: String): Int = when (type) {
        "quake" -> 8
        "hail" -> 7
        "stormStrong" -> 6
        "stormApproach" -> 5
        "zonda" -> 4
        "wind" -> 3
        "frost" -> 2
        "stormWeak" -> 1
        else -> 0
    }

    private fun defaultUri(): Uri? =
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

    private fun alarmAttrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

    private fun makePlayer(app: Context, loop: Boolean, type: String): MediaPlayer? {
        // 1) el sonido propio del tipo de aviso
        val key = if (type in SOUND_TYPES) type else "stormStrong"
        try {
            app.assets.openFd("www/sounds/$key.ogg").use { fd ->
                val mp = MediaPlayer()
                mp.setAudioAttributes(alarmAttrs())
                mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                mp.isLooping = loop
                mp.prepare()
                return mp
            }
        } catch (e: Exception) {
        }
        // 2) respaldo: el tono de alarma del celular
        val uri = defaultUri() ?: return null
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(alarmAttrs())
            mp.setDataSource(app, uri)
            mp.isLooping = loop
            mp.prepare()
            mp
        } catch (e: Exception) {
            null
        }
    }

    /** Suena unos segundos el sonido de un tipo de aviso (para que la persona lo conozca). */
    fun playPreview(ctx: Context, type: String) {
        val app = ctx.applicationContext
        stopPreview()
        try {
            val am = app.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val cur = am.getStreamVolume(AudioManager.STREAM_ALARM)
            if (cur < max / 2) am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.6).toInt().coerceAtLeast(1), 0)
        } catch (e: Exception) {
        }
        val mp = makePlayer(app, false, type) ?: return
        mp.start()
        preview = mp
        handler.postDelayed(previewOff, 5200L)
    }

    private fun stopPreview() {
        handler.removeCallbacks(previewOff)
        try {
            preview?.stop()
        } catch (e: Exception) {
        }
        try {
            preview?.release()
        } catch (e: Exception) {
        }
        preview = null
    }

    // ---------- ciclo 5 s sí / 20 s no ----------
    private fun startAlarm(app: Context, sound: Boolean, vibrate: Boolean, type: String) {
        silence()
        if (!sound && !vibrate) return
        appCtx = app
        wantSound = sound
        wantVib = vibrate
        wantType = type
        ringing = true
        stopPreview()
        // Con la pantalla apagada el CPU puede dormirse y los temporizadores atrasarse: se mantiene despierto mientras suena
        try {
            val pm = app.getSystemService(PowerManager::class.java)
            val l = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clima:alarma")
            l.acquire(MAX_MS + 60000L)
            ringLock = l
        } catch (e: Exception) {
        }
        if (sound) {
            try {
                val am = app.getSystemService(AudioManager::class.java)
                val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                val vol = (max * 0.9).toInt()
                am.setStreamVolume(AudioManager.STREAM_ALARM, if (vol < 1) 1 else vol, 0)
            } catch (e: Exception) {
            }
        }
        handler.postDelayed(giveUp, MAX_MS)
        buzzStart()
    }

    private fun buzzStart() {
        if (!ringing) return
        val app = appCtx ?: return
        if (wantSound) {
            stopSound()
            val mp = makePlayer(app, false, wantType)
            if (mp != null) {
                try {
                    mp.start()
                    player = mp
                } catch (e: Exception) {
                    try {
                        mp.release()
                    } catch (x: Exception) {
                    }
                }
            }
        }
        if (wantVib) {
            try {
                val v = app.getSystemService(Vibrator::class.java)
                v.vibrate(VibrationEffect.createWaveform(patternFor(wantType), -1), alarmAttrs())
            } catch (e: Exception) {
            }
        }
        handler.postDelayed(buzzOff, BUZZ_MS)
    }

    /** Cada tipo vibra distinto (siempre dura unos 5 s): se reconoce sin mirar la pantalla. */
    private fun patternFor(type: String): LongArray = when (type) {
        "quake" -> longArrayOf(0, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120, 80, 120)
        "hail" -> longArrayOf(0, 250, 120, 250, 120, 250, 120, 250, 120, 250, 120, 250, 120, 250, 120, 250, 120, 250, 120, 250)
        "stormStrong" -> longArrayOf(0, 700, 250, 700, 250, 700, 250, 700, 250, 700, 250)
        "stormApproach" -> longArrayOf(0, 400, 700, 400, 700, 400, 700, 400, 700)
        "wind", "zonda" -> longArrayOf(0, 1500, 500, 1500, 500, 800)
        "frost" -> longArrayOf(0, 100, 150, 100, 600, 100, 150, 100, 600, 100, 150, 100, 600, 100, 150, 100)
        else -> longArrayOf(0, 500, 400, 500, 400, 500)
    }

    private fun buzzStop() {
        if (!ringing) return
        stopSound()
        stopVib()
        handler.postDelayed(buzzOn, PAUSE_MS)
    }

    private fun stopSound() {
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    private fun stopVib() {
        try {
            appCtx?.getSystemService(Vibrator::class.java)?.cancel()
        } catch (e: Exception) {
        }
    }

    private fun wakeScreen(app: Context) {
        try {
            val pm = app.getSystemService(PowerManager::class.java)
            val wl = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "clima:pantalla"
            )
            wl.acquire(10000L)
        } catch (e: Exception) {
        }
    }

    /** Corta sonido y vibración y el ciclo. */
    fun silence() {
        ringing = false
        handler.removeCallbacks(buzzOn)
        handler.removeCallbacks(buzzOff)
        handler.removeCallbacks(giveUp)
        stopSound()
        stopVib()
        try {
            val l = ringLock
            if (l != null && l.isHeld) l.release()
        } catch (e: Exception) {
        }
        ringLock = null
    }

    /** "Leída / abierta": corta todo y borra las notificaciones de alerta (menos las de estado). */
    fun stop(ctx: Context) {
        appCtx = ctx.applicationContext
        cancelSpeech()
        silence()
        stopPreview()
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            for (sn in nm.activeNotifications) {
                if (sn.id != 1 && sn.id != Health.NOTIF_ID) nm.cancel(sn.id)
            }
        } catch (e: Exception) {
        }
    }
}
