package ar.mdz.clima

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Historial de avisos (los últimos 60) para volver a leerlos en Alertas > Recientes. */
object Hist {
    fun add(ctx: Context, title: String, body: String, type: String) {
        try {
            val p = Store.p(ctx)
            val old = try { JSONArray(p.getString("hist", "[]")) } catch (e: Exception) { JSONArray() }
            val o = JSONObject()
            o.put("t", System.currentTimeMillis())
            o.put("title", title)
            o.put("body", body)
            o.put("type", type)
            val out = JSONArray()
            out.put(o)
            for (i in 0 until minOf(old.length(), 59)) out.put(old.get(i))
            p.edit().putString("hist", out.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun get(ctx: Context): String = Store.p(ctx).getString("hist", "[]") ?: "[]"

    fun clear(ctx: Context) {
        Store.p(ctx).edit().remove("hist").apply()
    }
}
