package ar.mdz.clima

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Las estaciones de FePEDI / ISCAMEN / COVIAR se muestran en https://fepedi.evolus.com.ar/estaciones/ (mapa gratuito).
 * La app abre esa misma página en una pantalla oculta, deja que ella arme el mapa y lee lo que muestra
 * (como lo haría una persona mirándola). Debe llamarse desde el hilo principal.
 */
object FepediScraper {
    private const val URL = "https://fepedi.evolus.com.ar/estaciones/"
    private var busy = false

    fun run(ctx: Context, lat: Double, lon: Double, done: (String) -> Unit) {
        if (busy) {
            done("{\"error\":\"ya se está consultando\"}")
            return
        }
        val script = try {
            ctx.assets.open("www/fepedi_scrape.js").bufferedReader().use { it.readText() }
                .replace("__LAT__", lat.toString()).replace("__LON__", lon.toString())
        } catch (e: Exception) {
            done("{\"error\":\"falta el lector\"}")
            return
        }
        busy = true
        val handler = Handler(Looper.getMainLooper())
        val wv = WebView(ctx)
        var finished = false
        var started = false
        var tries = 0
        var attachedTo: android.view.ViewGroup? = null
        try {
            val decor = (ctx as? android.app.Activity)?.window?.decorView as? android.view.ViewGroup
            if (decor != null) {
                val lp = android.widget.FrameLayout.LayoutParams(1080, 1920)
                wv.layoutParams = lp
                wv.translationX = -12000f
                decor.addView(wv, lp)
                attachedTo = decor
            }
        } catch (e: Exception) {
        }
        fun finish(json: String) {
            if (finished) return
            finished = true
            busy = false
            handler.removeCallbacksAndMessages(null)
            try {
                attachedTo?.removeView(wv)
            } catch (e: Exception) {
            }
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (e: Exception) {
            }
            done(json)
        }
        lateinit var poll: Runnable
        poll = Runnable {
            if (finished) return@Runnable
            wv.evaluateJavascript("(window.__fp&&window.__fp.done)?JSON.stringify(window.__fp):''") { res ->
                if (finished) return@evaluateJavascript
                try {
                    val str = JSONTokener(res).nextValue() as? String ?: ""
                    if (str.isNotEmpty()) {
                        finish(str)
                        return@evaluateJavascript
                    }
                } catch (e: Exception) {
                }
                tries++
                if (tries < 60) handler.postDelayed(poll, 800) else finish("{\"error\":\"tardó demasiado\"}")
            }
        }
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        wv.webViewClient = object : WebViewClient() {
            // Se descartan imágenes y mosaicos del mapa (no hacen falta para leer los datos): ahorra datos y batería.
            override fun shouldInterceptRequest(view: WebView?, request: android.webkit.WebResourceRequest?): android.webkit.WebResourceResponse? {
                val u = request?.url?.toString() ?: return null
                if (Regex("\\.(png|jpe?g|gif|webp|svg|ico)(\\?.*)?$", RegexOption.IGNORE_CASE).containsMatchIn(u) || u.contains("tile.openstreetmap.org")) {
                    return android.webkit.WebResourceResponse("image/png", null, java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!finished && !started) {
                    started = true
                    wv.evaluateJavascript(script, null)
                    handler.postDelayed(poll, 1500)
                }
            }

            override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request != null && request.isForMainFrame) finish(JSONObject().put("error", "no abrió la página (" + (error?.description ?: "error") + ")").toString())
            }
        }
        handler.postDelayed({ finish("{\"error\":\"tardó demasiado\"}") }, 50000)
        wv.loadUrl(URL)
    }
}
