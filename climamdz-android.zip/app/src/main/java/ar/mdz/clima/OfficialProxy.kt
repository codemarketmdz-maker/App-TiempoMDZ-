package ar.mdz.clima

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * Los sitios oficiales (SMN, Gobierno de Mendoza, INPRES) no mandan el permiso CORS, así que
 * la página no puede leerlos directamente. Acá se bajan desde Android y se entregan a la página
 * con el permiso agregado. Solo se atienden estos dominios y solo pedidos GET.
 */
object OfficialProxy {
    private val HOSTS = listOf("smn.gob.ar", "mendoza.gov.ar", "inpres.gob.ar", "aviationweather.gov")
    private const val MAX_BYTES = 6 * 1024 * 1024

    private val CORS = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Access-Control-Allow-Headers" to "*",
        "Access-Control-Allow-Methods" to "GET, OPTIONS",
        "Access-Control-Expose-Headers" to "X-Proxy-Error, Retry-After",
        "Cache-Control" to "no-store"
    )

    private fun handles(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return HOSTS.any { h == it || h.endsWith(".$it") }
    }

    private fun empty(code: Int, reason: String, err: String? = null) =
        WebResourceResponse("text/plain", "utf-8", code, reason,
            if (err == null) CORS else CORS + mapOf("X-Proxy-Error" to err.replace(Regex("[\\r\\n]"), " ").take(120)),
            ByteArrayInputStream(ByteArray(0)))

    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36 TiempoMDZ/1.15"

    fun intercept(r: WebResourceRequest): WebResourceResponse? {
        val u = r.url
        if (r.isForMainFrame || u.scheme != "https" || !handles(u.host)) return null
        if (r.method == "OPTIONS") return empty(204, "No Content")
        if (r.method != "GET") return null
        return try {
            // Se siguen a mano hasta 5 redirecciones (también de http a https), solo dentro de los sitios permitidos.
            var cur = u.toString()
            var hops = 0
            var c = URL(cur).openConnection() as HttpURLConnection
            while (true) {
                c.connectTimeout = 7000
                c.readTimeout = 9000
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Accept", r.requestHeaders["Accept"] ?: "*/*")
                c.setRequestProperty("Accept-Language", "es-AR,es;q=0.9")
                val rc = c.responseCode
                val loc = c.getHeaderField("Location")
                if (rc in intArrayOf(301, 302, 303, 307, 308) && loc != null && hops < 5) {
                    var next = URL(URL(cur), loc).toString()
                    if (next.startsWith("http://")) next = "https://" + next.removePrefix("http://")
                    if (!handles(Uri.parse(next).host)) return empty(502, "Bad Gateway", "redirect fuera de sitio permitido")
                    cur = next
                    hops++
                    c.disconnect()
                    c = URL(cur).openConnection() as HttpURLConnection
                    continue
                }
                break
            }
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else c.errorStream
            val bytes = readLimited(stream)
            val ct = c.contentType ?: "application/octet-stream"
            val mime = ct.substringBefore(';').trim().lowercase()
            val declared = Regex("charset=([^;\\s]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
            val isText = mime.startsWith("text/") || mime.contains("xml") || mime.contains("json") || mime.contains("javascript")
            // fetch().text() siempre lee UTF-8: si la página viene en otra codificación, se convierte.
            val body = if (isText) toUtf8(bytes, declared) else bytes
            val status = if (code in 300..399) 502 else code.coerceIn(200, 599)
            val reason = (c.responseMessage ?: "").ifBlank { if (status < 400) "OK" else "Error" }
            val hdr = c.getHeaderField("Retry-After")?.let { CORS + mapOf("Retry-After" to it) } ?: CORS
            WebResourceResponse(mime, if (isText) "utf-8" else null, status, reason, hdr, ByteArrayInputStream(body))
        } catch (e: Exception) {
            empty(504, "Gateway Timeout", e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    private fun readLimited(s: java.io.InputStream?): ByteArray {
        if (s == null) return ByteArray(0)
        return s.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (out.size() < MAX_BYTES) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
            out.toByteArray()
        }
    }

    private fun validUtf8(b: ByteArray): Boolean = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b))
        true
    } catch (e: Exception) {
        false
    }

    private val W1252: Charset = try { Charset.forName("windows-1252") } catch (e: Exception) { Charsets.ISO_8859_1 }

    /** Entrega siempre UTF-8 válido: si dice UTF-8 pero los bytes no lo son (caso típico: tildes en Latin-1), se corrige. */
    private fun toUtf8(bytes: ByteArray, declared: String?): ByteArray {
        var cs: Charset? = try { declared?.let { Charset.forName(it) } } catch (e: Exception) { null }
        if (cs == null) {
            val head = String(bytes, 0, minOf(bytes.size, 200), Charsets.ISO_8859_1)
            val m = Regex("encoding\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(head)
            cs = try { m?.let { Charset.forName(it.groupValues[1]) } } catch (e: Exception) { null }
        }
        if (cs == null || cs == Charsets.UTF_8) {
            return if (validUtf8(bytes)) bytes else String(bytes, W1252).toByteArray(Charsets.UTF_8)
        }
        return String(bytes, cs).toByteArray(Charsets.UTF_8)
    }
}
