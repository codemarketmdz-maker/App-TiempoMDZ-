package ar.mdz.clima

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Voz en español (motor de texto a voz del celular, sin internet).
 * Para que SIEMPRE hable, se crea un motor nuevo en cada aviso y se cierra al terminar:
 * un motor reutilizado suele quedar dormido o cerrado por el sistema y deja de hablar sin avisar.
 */
object Voice {
    private var tts: TextToSpeech? = null
    private var pending: String? = null
    private var pendingUsage = AudioAttributes.USAGE_ALARM
    private var token = 0L
    private val main = Handler(Looper.getMainLooper())

    fun enabled(ctx: Context): Boolean = Store.p(ctx).getBoolean("voice", true)

    fun clean(t: String): String = t
        .replace("km/h", " kilómetros por hora")
        .replace("°C", " grados")
        .replace("°", " grados")
        .replace(Regex("[^\\p{L}\\p{N}\\s.,:;%()¿?¡!-]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    fun speak(ctx: Context, text: String, alarm: Boolean) {
        val t = clean(text)
        if (t.isEmpty()) return
        val usage = if (alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE
        reset()
        pending = t
        pendingUsage = usage
        val my = ++token
        try {
            tts = TextToSpeech(ctx.applicationContext) { st ->
                if (my != token) return@TextToSpeech
                if (st != TextToSpeech.SUCCESS) { reset(); return@TextToSpeech }
                val en = tts ?: return@TextToSpeech
                setEs(en)
                try {
                    en.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { main.postDelayed({ if (my == token) reset() }, 700) }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { main.post { if (my == token) reset() } }
                    })
                } catch (x: Exception) { }
                val p = pending ?: return@TextToSpeech
                pending = null
                try {
                    en.setAudioAttributes(
                        AudioAttributes.Builder().setUsage(pendingUsage)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    en.speak(p, TextToSpeech.QUEUE_FLUSH, null, "cm$my")
                } catch (x: Exception) {
                    reset()
                }
            }
        } catch (x: Exception) {
            tts = null
        }
    }

    private fun reset() {
        try { tts?.stop() } catch (x: Exception) { }
        try { tts?.shutdown() } catch (x: Exception) { }
        tts = null
    }

    private fun setEs(e: TextToSpeech) {
        for (loc in listOf(Locale("es", "AR"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))) {
            val r = try { e.setLanguage(loc) } catch (x: Exception) { TextToSpeech.LANG_NOT_SUPPORTED }
            if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) return
        }
    }

    fun stop() {
        token++
        pending = null
        reset()
    }
}
