package ar.mdz.clima

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Voz de los avisos: usa la voz en español que ya trae el celular (funciona sin internet).
 * Si el celular no tiene voz en español, no habla y queda el sonido de siempre.
 */
object Voice {
    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var pending: String? = null
    private var lock: PowerManager.WakeLock? = null
    private val release = Runnable { shutdown() }

    /** La voz es una función Pro (la prueba gratis también cuenta como Pro). */
    fun allowed(ctx: Context): Boolean = try { License.status(ctx).optString("tier") == "pro" } catch (e: Exception) { false }

    fun enabled(ctx: Context): Boolean = allowed(ctx) && Store.p(ctx).getBoolean("voice_on", true)

    private fun attrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    /** Prepara el motor de voz (tarda ~1 s la primera vez). */
    fun prepare(ctx: Context) {
        if (tts != null || failed) return
        val app = ctx.applicationContext
        try {
            tts = TextToSpeech(app) { status ->
                handler.post {
                    if (status != TextToSpeech.SUCCESS) {
                        failed = true
                        shutdown()
                    } else {
                        val t = tts
                        var ok = false
                        if (t != null) {
                            for (loc in listOf(Locale("es", "AR"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))) {
                                val r = t.isLanguageAvailable(loc)
                                if (r >= TextToSpeech.LANG_AVAILABLE) {
                                    t.language = loc
                                    ok = true
                                    break
                                }
                            }
                            if (ok) {
                                t.setAudioAttributes(attrs())
                                t.setSpeechRate(0.95f)
                            }
                        }
                        if (!ok) {
                            failed = true
                            shutdown()
                        } else {
                            ready = true
                            val p = pending
                            pending = null
                            if (p != null) speakNow(p)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            failed = true
        }
    }

    /** Dice el texto en voz alta (si la voz está activada y el celular tiene voz en español). */
    fun speak(ctx: Context, text: String, force: Boolean = false) {
        if (text.isBlank() || !allowed(ctx)) return
        if (!force && !enabled(ctx)) return
        keepAwake(ctx)
        if (failed) return
        prepare(ctx)
        if (ready) speakNow(text) else pending = text
    }

    private fun speakNow(text: String) {
        try {
            tts?.speak(text.take(400), TextToSpeech.QUEUE_FLUSH, null, "aviso")
        } catch (e: Exception) {
        }
        handler.removeCallbacks(release)
        handler.postDelayed(release, 45000L) // se libera el motor un rato después de hablar
    }

    private fun keepAwake(ctx: Context) {
        try {
            val l = lock
            if (l != null && l.isHeld) l.release()
            val pm = ctx.applicationContext.getSystemService(PowerManager::class.java)
            val n = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clima:voz")
            n.acquire(40000L)
            lock = n
        } catch (e: Exception) {
        }
    }

    fun stop() {
        pending = null
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
    }

    private fun shutdown() {
        handler.removeCallbacks(release)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ready = false
        try {
            val l = lock
            if (l != null && l.isHeld) l.release()
        } catch (e: Exception) {
        }
        lock = null
    }
}
