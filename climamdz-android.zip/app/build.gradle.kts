plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ar.mdz.clima"
    compileSdk = 34

    defaultConfig {
        // ID nuevo para instalar TiempoMDZ en paralelo con la app anterior (ar.mdz.clima).
        applicationId = "ar.mdz.tiempomdz"
        minSdk = 26
        targetSdk = 34
        versionCode = 31
        versionName = "1.15.1"
    }

    val signingStorePath = System.getenv("ANDROID_KEYSTORE_PATH")
    val signingStorePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
    val signingKeyAlias = System.getenv("ANDROID_KEY_ALIAS")
    val signingKeyPassword = System.getenv("ANDROID_KEY_PASSWORD")
    val canSignRelease = signingStorePath != null && signingStorePath.isNotBlank() &&
        !signingStorePassword.isNullOrBlank() && !signingKeyAlias.isNullOrBlank() &&
        !signingKeyPassword.isNullOrBlank() && file(signingStorePath).exists()

    if (canSignRelease) {
        signingConfigs {
            create("tiempomdz") {
                storeFile = file(signingStorePath!!)
                storePassword = signingStorePassword!!
                keyAlias = signingKeyAlias!!
                keyPassword = signingKeyPassword!!
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (canSignRelease) signingConfig = signingConfigs.getByName("tiempomdz")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
